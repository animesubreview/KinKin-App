package me.kinkinmichan.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.splash_logo);
        TextView title = findViewById(R.id.splash_title);
        TextView subtitle = findViewById(R.id.splash_subtitle);
        ProgressBar progressBar = findViewById(R.id.splash_progress);

        // Logo pop animation
        logo.setScaleX(0f);
        logo.setScaleY(0f);
        logo.setAlpha(0f);

        ObjectAnimator scaleX = ObjectAnimator.ofFloat(logo, "scaleX", 0f, 1.1f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(logo, "scaleY", 0f, 1.1f, 1f);
        ObjectAnimator alpha = ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f);

        AnimatorSet logoAnim = new AnimatorSet();
        logoAnim.playTogether(scaleX, scaleY, alpha);
        logoAnim.setDuration(700);
        logoAnim.setInterpolator(new OvershootInterpolator(1.5f));
        logoAnim.start();

        // Title fade up
        title.setAlpha(0f);
        title.setTranslationY(30f);
        title.animate().alpha(1f).translationY(0f).setDuration(500).setStartDelay(600)
                .setInterpolator(new DecelerateInterpolator()).start();

        // Subtitle fade up
        subtitle.setAlpha(0f);
        subtitle.setTranslationY(30f);
        subtitle.animate().alpha(1f).translationY(0f).setDuration(500).setStartDelay(800)
                .setInterpolator(new DecelerateInterpolator()).start();

        // Progress bar fade in
        progressBar.setAlpha(0f);
        progressBar.animate().alpha(1f).setDuration(300).setStartDelay(900).start();

        // Navigate to MainActivity after 2.5s
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 2500);
    }
}
