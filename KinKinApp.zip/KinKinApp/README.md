# 📱 KinKin Android App

App Android WebView cho website kinkinmichan.me

---

## 🚀 Cách build APK (3 cách)

### Cách 1: Dùng Android Studio (Khuyên dùng)

1. Tải **Android Studio**: https://developer.android.com/studio
2. Mở Android Studio → **Open** → chọn thư mục `KinKinApp`
3. Đợi Gradle sync xong
4. Thêm icon app: Copy file logo PNG vào các thư mục:
   - `res/mipmap-hdpi/` → 72x72px
   - `res/mipmap-xhdpi/` → 96x96px  
   - `res/mipmap-xxhdpi/` → 144x144px
   - `res/mipmap-xxxhdpi/` → 192x192px
   - Đặt tên file: `ic_launcher.png` và `ic_launcher_round.png`
5. Menu **Build** → **Build Bundle(s)/APK(s)** → **Build APK(s)**
6. APK xuất ra: `app/build/outputs/apk/debug/app-debug.apk`

---

### Cách 2: Dùng online builder (Không cần cài phần mềm)

1. Vào https://www.appssgeyser.com
2. Chọn **WebView App**
3. Nhập URL: `https://kinkinmichan.me`
4. Upload logo, đặt tên **KinKin**
5. Build và tải APK về

---

### Cách 3: Dùng Buildozer / GitHub Actions (Nâng cao)

Upload code lên GitHub → Dùng GitHub Actions để build APK tự động.

---

## 📦 Tính năng app

- ✅ Load website kinkinmichan.me trong WebView
- ✅ Màn hình splash với logo và animation đẹp
- ✅ Thanh progress khi tải trang
- ✅ Hỗ trợ phát video
- ✅ Nút back điều hướng trong web
- ✅ Link ngoài mở trình duyệt
- ✅ Hỗ trợ upload file
- ✅ Theme tối #0a0a0f + màu vàng #f59e0b

---

## ⚙️ Thông tin app

- **Package**: me.kinkinmichan.app
- **Min Android**: 5.0 (API 21)
- **Target**: Android 14 (API 34)
